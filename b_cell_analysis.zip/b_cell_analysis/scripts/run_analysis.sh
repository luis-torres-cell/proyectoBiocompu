#!/bin/bash

# Configuración
INPUT_DIR="data"
OUTPUT_DIR="output"

# Crear carpeta de salida si no existe
mkdir -p $OUTPUT_DIR

echo "===== Análisis de Lisosomas en Linfocitos B ====="

# Procesar imágenes y analizar datos
echo "Procesando imágenes y analizando datos..."
python3 scripts/analyze_data.py $INPUT_DIR $OUTPUT_DIR

echo "===== Análisis Completado ====="
echo "Los resultados se encuentran en la carpeta: $OUTPUT_DIR"
